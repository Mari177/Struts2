
      function checkData(){
        // event.preventDefault();
          var name = document.getElementById("name").value;
          var surname = document.getElementById("surname").value;
          var email = document.getElementById("email").value;
          var phoneNumber = document.getElementById("phonenumber").value;
          var password = document.getElementById("password").value;
          var confirmpassword = document.getElementById("confirmpassword").value;
          var count=0;
          if(name ==='')
          {
            document.getElementById('namesmall').innerHTML="Fill the Name";
            count++;
          }
          else
          {
            document.getElementById('namesmall').innerHTML="";
          }
          if(surname === '')
          {
            document.getElementById('namesurname'). innerHTML="Fill the Sur Name";
            count++;
          }
          else
          {
            document.getElementById('namesurname').innerHTML="";
          }
          if(email === '')
          {
            document.getElementById('nameemail').innerHTML="Fill the Email";
            count++;
          }
          else
          {
            document.getElementById('nameemail').innerHTML="";
          }
          if(phoneNumber === '')
          {
            document.getElementById('nameph').innerHTML="Fill the Phone Number";
            count++;
          }
          else
          {
            document.getElementById('nameph').innerHTML="";
          }
          if(password === '')
          {
            document.getElementById('namepass').innerHTML="Fill the Password";
            count++;
          }
          else
          {
            document.getElementById('namepass').innerHTML="";
          }
          if(confirmpassword === '')
          {
            document.getElementById('namecfmpass').innerHTML="Fill the Confirm Password";
            count++;
          }
          else
          {
            document.getElementById('namecfmpass').innerHTML="";
          }
          //console.log("Count : " + count);
          if(count==0 && validation()==0)
          {
            console.log(name);
            console.log(surname);
            console.log(email);
            console.log(phoneNumber);
            document.registration.submit();
          }
        }
          function validation(){
            var count=0;
            if(checkFirstName()==null)
            {
              document.getElementById('namesmall').innerHTML="First Name must be only string";
              count++;
            }
            if(checkLastName()==null)
            {
              document.getElementById('namesurname').innerHTML="Last Name must be only string";
              count++;
            }
            else
            {
              document.getElementById('namesurname').innerHTML="";
            }
            if(checkPhoneNumber()==null)
            {
              document.getElementById('nameph').innerHTML="Phone number is invalid";
              count++;
            }
            else
            {
              document.getElementById('nameph').innerHTML="";
            }
            if(checkEmail()==null)
            {
              document.getElementById('nameemail').innerHTML="Email address is invalid";
              count++;
            }
            else
            {
              document.getElementById('nameemail').innerHTML="";
            }
            if(passwordEquals()==0)
            {
              document.getElementById('namepass').innerHTML="Passwords do not match";
              //document.getElementById('namecfmpass').innerHTML="Passwords do not match";
              count++;
            }
            else if(validatePassword()==null)
            {
              document.getElementById('namepass').innerHTML="Passwords do not meet our requirements";
              count++;
              
            }
            else
            {
              document.getElementById('namepass').innerHTML="";
            }
          
            return count;
            
          }
          function passwordEquals()
          {
            var password=document.getElementById("password").value;
            var password2=document.getElementById("confirmpassword").value;
            var pattern=new RegExp(password,"gi");
            if(pattern.test(password2))
              return 1;
            else
              return 0;
          }
          function checkPhoneNumber()
          {
            var pattern =/^[0-9]*$/;
            var phoneNumber=document.getElementById("phonenumber").value;
           // console.log(pattern.test(phoneNumber));
            return (phoneNumber.match(pattern));
          }
          function checkFirstName()
          {
            var name = document.getElementById("name").value;
            
            var regName=/^[A-Za-z\s]*$/;  
          
            return (regName.test(name));
          }
          function checkLastName()
          {
            var surname=document.getElementById("surname").value;
            var regName="^[a-zA-Z]+$";
            return (surname.match(regName));
          }
          function checkEmail()
          {
            var email=document.getElementById("email").value;
            var regEmail=/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
            //console.log(email.match(regEmail));
            return email.match(regEmail);
          }
          function validatePassword()
          {
            var password=document.getElementById("password").value;
            var regex=/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/;
            console.log(password.match(regex));
            return password.match(regex);
          }
        