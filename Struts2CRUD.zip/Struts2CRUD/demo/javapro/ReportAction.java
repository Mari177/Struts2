package demo.javapro;
import java.util.ArrayList;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.Statement;
//import com.opensymphony.xwork2.ActionSupport;
public class ReportAction{
    Person obj=null;
    
    ArrayList<Person> list=null;
    
    boolean noData=false;
    public boolean getNoData() {
        return noData;
    }
    public ArrayList<Person> getList() {
        return list;
    }
    public void setList(ArrayList<Person> list) {
        this.list = list;
    }
    public void setNoData(boolean noData) {
        this.noData = noData;
    }
    public String execute()
    {
        Connection con=null;
        ResultSet rs=null;
        Statement smt=null;
        try
        { 
            list=new ArrayList<Person>();
            String query="select * from Person ";
           
            con=Register.getConnection();
            smt=con.createStatement();
            rs=smt.executeQuery(query);
           
            while(rs.next())
            {
                Person std=new Person();
                std.setId(rs.getInt(1));
                std.setFirstName(rs.getString(2));
                std.setSurName(rs.getString(3));
                std.setEmail(rs.getString(4));
                std.setPhoneNumber(rs.getLong(5));
                std.setPassword(rs.getString(6));
                list.add(std);
            }
            
            
            rs.close();
            if(list.size()>0)
                noData=false;
            else
                noData=true;
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }  
        finally{
            try{
                rs.close();
                smt.close();
                con.close();
            }
            catch(Exception e){}
        } 
        return "REPORT";     
    
    }
        
    }



