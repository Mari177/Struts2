package demo.javapro;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.sql.SQLException;
import java.sql.ResultSet;
//import java.security.acl.Permission;
import java.sql.Statement;
public class Register{
	static 
	{
        try{
		Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e){}
	}
    public static Connection getConnection()throws SQLException    
    {
        String conname="root";
        String conpassword="";
        String url="jdbc:mysql://localhost:3306/TestDB";
        Connection con=DriverManager.getConnection(url, conname, conpassword);
        return con;
    }
    public static void closePrepareStatement(PreparedStatement obj)
    {
        try{
            obj.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    public static void closeConnection(Connection obj)
    {
        try{
            obj.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    public static void closeResultSet(ResultSet obj)
    {
        try{
            obj.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    public static void closeStatement(Statement obj)
    {
        try{
            obj.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    public static int DetailsUpdate(String firstName,String surName,String email,long phoneNumber,String password)
    {
        // System.out.println("\nName : " + name + " \t Age" + age + " \tPhoenNumber "+ PhoneNumber+"\t Address : " + address);

        Connection con=null;
        int row=0;
        PreparedStatement pps=null;
        try
        {
        con=getConnection();
        String query="insert into Person(firstName,surName,email,phoneNumber,password) values(?,?,?,?,?)";
        pps=con.prepareStatement(query);
        System.out.println(phoneNumber);
       // System.out.println(name + age + PhoneNumber + address);
        pps.setString(1,firstName);
        pps.setString(2,surName);
        pps.setString(3,email);
        pps.setLong(4,phoneNumber);
        pps.setString(5,password);
        row=pps.executeUpdate();
       
        }
        catch(SQLException e)
        {
            System.out.println("\nException : " + e);
        }
        finally{
            closePrepareStatement(pps);
            closeConnection(con);
        }
        //System.out.println("nROw is Updated" + row);
        return row;
        
    }
    /*public static int GetCount()
    {
        return getStudentList().size();
    }*/
    public static ResultSet report()
    {
        Connection con=null;
        Statement smt=null;
        ResultSet rs=null;
        String query="select * from Person ";
        
        try{
            con=getConnection();
            smt=con.createStatement();
            rs=smt.executeQuery(query);
            return rs; 
           }
        catch(SQLException e){}
        finally{
            closeConnection(con);
            closeStatement(smt);
        }
        return null;
    }
    public static int DeleteRecord(int id)
    {
        Connection con=null;
        PreparedStatement ps=null;
        String query="delete from Person where personId=? ";
        int val=id;
        int count=0;
        try{
            con=getConnection();
            ps=con.prepareStatement(query);
            ps.setInt(1,val);
            count=ps.executeUpdate();
            count++;       
    }
    catch(Exception e)
    {
        e.printStackTrace();
    }
    finally
    {
        closeConnection(con);
        closePrepareStatement(ps);   
    }
    return count;
    }
    public static Person EditRecord(int id)
    {
        Connection con=null;
        String query="Select * from Person";
        // ArrayList<Student> list=new ArrayList<>();
        Statement smt=null;
        ResultSet rs=null;
        Person std=null;
        try{
            con=getConnection();
            smt=con.createStatement();
            rs=smt.executeQuery(query);
            while(rs.next())
            {
                if(rs.getInt(1)==id)
                {    
                    std=new Person();
                    std.setId(rs.getInt(1));
                    std.setFirstName(rs.getString(2));
                    std.setSurName(rs.getString(3));
                    std.setEmail(rs.getString(4));
                    std.setPhoneNumber(rs.getLong(5));
                    std.setPassword(rs.getString(6));
                    // list.add(std);

                }
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally{
            closeConnection(con);
            closeStatement(smt);
            closeResultSet(rs);
        }
        return std;
    }
    public static int  UpdateRecord(int id,String firstName,String surName,String email,long phoneNumber)
    {
        Connection con=null;
        PreparedStatement pps=null;
        int row=0;
        try
        {
            con=getConnection();
            String query="update Person set firstName=?,surName=?,email=?,phoneNumber=? where personId=?;";
            pps=con.prepareStatement(query);
            pps.setString(1,firstName);
            pps.setString(2,surName);
            pps.setString(3,email);
            pps.setLong(4,phoneNumber);
            pps.setInt(5,id);
            row=pps.executeUpdate();
        }
        catch(Exception e)
        {
            System.out.println("\nException : " + e);
        }
        finally{
            closeConnection(con);
            closePrepareStatement(pps);
        }
        return row;
    }
}
