package demo.javapro;
public class RegisterAction
{
    private String firstName,surName,email;
    private long phoneNumber;
    private int id;
    private String password;
    String msg;
    int result;
    public int getResult() {
        return result;
    }
    public void setResult(int result) {
        this.result = result;
    }
    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    
    public String execute()
    {
        try
        {
            System.out.println ("Hello");
           result= Register.DetailsUpdate(firstName,surName,email,phoneNumber,password);
           if (result>0)
                msg="Registration Successfull";
            else
                msg="Failed to Register";
        }
        catch(Exception e)
        {
            System.out.println("hello");
            e.printStackTrace();
        }
        return "REGISTER";
    }
    public void setFirstName(String firstName)
    {
        this.firstName=firstName;
    }    
    public void setSurName(String surName)
    {
        this.surName=surName;
    }
    public void setEmail(String email)
    {
        this.email=email;
    }
    public void setPhoneNumber(long phoneNumber)
    {
        this.phoneNumber=phoneNumber;
    }
    public void setPassword(String password)
    {
        this.password=password;
    }
    public long getPhoneNumber()
    {
        return phoneNumber;
    }
    public String getPassword()
    {
        return password;
    }
    public String getFirstName()
    {
        return firstName;
    }
    public String getSurName()
    {
        return surName;
    }
    public String getEmail()
    {
        return email;
    }
    public int getPersonId()
    {
        return id;
    }
   /*  public String getMessage()
    {
        return msg;
    }
    public int getResult()
    {
        return result;
    }
    /*public void setMessage(String message)
    {
        msg=message;
    }
    public void setResult(int result)
    {
        this.result=result;
    }*/

    
}
