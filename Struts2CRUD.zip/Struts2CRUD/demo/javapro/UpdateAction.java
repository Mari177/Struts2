package demo.javapro;
//import java.sql.ResultSet;

public class UpdateAction
{
    private String firstName,surName,email;
    private long phoneNumber;
    private int id;
    private String password;
    private String msg;
    private int result;
    Person obj;

    public Person getObj() {
        return obj;
    }

    public void setObj(Person obj) {
        this.obj = obj;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getSurName() {
        return this.surName;
    }

    public void setSurName(String surName) {
        this.surName = surName;
    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public long getPhoneNumber() {
        return this.phoneNumber;
    }

    public void setPhoneNumber(long phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMsg() {
        return this.msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public int getResult() {
        return this.result;
    }

    public void setResult(int result) {
        this.result = result;
    }
    public String execute()
    {
       try
       {
        System.out.println("hello");
        this.obj=Register.EditRecord(id);
       // result = Register.UpdateRecord(obj.getId(), obj.getFirstName(), obj.getSurName(),obj.getEmail(),obj.getPhoneNumber());
       if(result>0)
            msg="Updated Successfull";
        else
            msg="No Updates";
       }
       catch(Exception e)
       {
            e.printStackTrace();
       }
       return "UPDATE";
    }

}