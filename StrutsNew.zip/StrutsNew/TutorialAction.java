public class TutorialAction
{
    public String execute()
    {
       System.out.println("Hello from execute");
       return "success"; 
    }
}